default['couchbase']['client']['version'] = '2.0.3-1'
